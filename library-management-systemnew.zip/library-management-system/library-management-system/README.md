# library-management-system
This is a Library Management System that I had created as one of my projects in the Database Design course at University of Texas at Dallas.
This project uses JSP servlet pages for the front-end and MySql database at the back-end.
